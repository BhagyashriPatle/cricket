package com.example.mycricketapplication.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.mycricketapplication.R

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
    }
}