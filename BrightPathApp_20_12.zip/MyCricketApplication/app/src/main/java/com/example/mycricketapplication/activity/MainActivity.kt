package com.example.mycricketapplication.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.mycricketapplication.R

import android.content.Intent
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.example.mycricketapplication.databinding.ActivityMainBinding
import com.example.mycricketapplication.fragments.HomeFragment
import com.example.mycricketapplication.fragments.CourseFragment
import com.example.mycricketapplication.fragments.MoreFragment
import com.example.mycricketapplication.fragments.BooksFragment
import com.example.mycricketapplication.fragments.ClassesFragment


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    var currentFragment = ""
    var redirectFrom = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  mySharedPreferences = MySharedPreferences.getInstance(this)!!
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)

        initData()
        println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")

    }


    private fun initData() {
        loadFragment(HomeFragment(), "home")
        // Set default fragment

        selectBottomViewItems()

        binding.appBar.profile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }

    }


    private fun selectBottomViewItems() {
        binding.bottomNavigationView.selectedItemId = R.id.home
        binding.bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.home -> {
                    //  setHomeFragment()
                    loadFragment(HomeFragment(), "home")
                    currentFragment = "home"
                    true
                }

                R.id.course -> {
                    loadFragment(CourseFragment(), "course")
                    currentFragment = "course"

                    true
                }

                R.id.classes -> {
                    loadFragment(BooksFragment(), "class")
                    currentFragment = "class"

                    true
                }

                R.id.books -> {
                    loadFragment(ClassesFragment(), "book")
                    currentFragment = "book"

                    true
                }


                R.id.more -> {
                    loadFragment(MoreFragment(), "more")
                    currentFragment = "more"
                    true
                }

                else -> {
                    false
                }
            }
        }

    }

    private fun loadFragment(fragment: Fragment, tag: String) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.container, fragment, tag).addToBackStack(null).commit()

    }

}
