package com.example.mycricketapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.databinding.DataBindingUtil
import com.example.mycricketapplication.R
import com.example.mycricketapplication.databinding.ActivitySplashBinding

class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding
    // private lateinit var mySharedPreferences: MySharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash)
        setLoopHandlerSplash()
    }

    private fun setLoopHandlerSplash() {
        Handler(Looper.myLooper()!!).postDelayed({
            checkStatus()
        }, 1500)
    }

    private fun checkStatus() {
        startActivity(Intent(this@SplashActivity, MainActivity::class.java))
        finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_in_left)
    }
}