package com.example.mycricketapplication.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.mycricketapplication.R

import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.autofill.FieldClassification.Match
import android.view.Menu
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.example.mycricketapplication.databinding.ActivityMainBinding
import com.example.mycricketapplication.fragments.HomeFragment
import com.example.mycricketapplication.fragments.MatchFragment
import com.example.mycricketapplication.fragments.MoreFragment
import com.example.mycricketapplication.fragments.PlayerFragment
import com.example.mycricketapplication.fragments.TicketFragment
import java.util.Timer
import java.util.TimerTask


class MainActivity : AppCompatActivity(){

    private lateinit var binding: ActivityMainBinding
    //  private lateinit var mySharedPreferences: MySharedPreferences
    var currentFragment = ""
    var redirectFrom = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  mySharedPreferences = MySharedPreferences.getInstance(this)!!
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        loadFragment(HomeFragment(),"home")

        initData()
        println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
        //  val userId = mySharedPreferences.userObjectModel?.user_id
//        if (userId != null) {
//          //  getUserInfo(userId)
//        }

        val callback: OnBackPressedCallback =
            object : OnBackPressedCallback(true) {
                @RequiresApi(Build.VERSION_CODES.O)
                override fun handleOnBackPressed() {
                    fragmentManager.popBackStack()///18004190157

                    println("getSupportFragmentManager().findFragmentByTag = ${supportFragmentManager.backStackEntryCount}")
                    println("getSupportFragmentManager().findFragmentByTag = ${supportFragmentManager.fragments}")
                    println(
                        "getSupportFragmentManager().findFragmentByTag = ${
                            supportFragmentManager.findFragmentByTag(
                                "home"
                            )
                        }"
                    )
                    val findFragmentByTag = supportFragmentManager.findFragmentByTag("home")
                    println("findFragmentByTag!!.id ===== ${findFragmentByTag!!.tag}")

                    val get = supportFragmentManager.fragments.get(0)
                    println("get ====== ${get}")
                    println("get tag ====== ${get.tag}")

                    if (get!!.tag == "home" || currentFragment == "home") {
                        //exitBlock()
                    } else {
                        binding.bottomNavigationView.selectedItemId = R.id.home
                        binding.appBar.logo.visibility = View.VISIBLE
                        loadFragment(HomeFragment(), "home")

                        binding.navigateHome.visibility = View.VISIBLE
                        val menu: Menu = binding.bottomNavigationView.menu
                        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._8ssp)
                        binding.bottomAppBar.fabCradleRoundedCornerRadius =
                            resources.getDimension(R.dimen._0ssp)
                        menu.findItem(R.id.home).icon = null
                        menu.findItem(R.id.home).title = ""
                    }
                }
            }
        this.onBackPressedDispatcher.addCallback(this, callback)
    }


//    private fun setCommunityFragmentWithBundle() {
//        val bundle = Bundle()
//        val extras = intent.extras
//        println("extras =??? ${extras}")
//        val FinalImageUri = Uri.parse(extras!!.getString("FinalImageUri"))
////        val FinalImageUri = Uri.parse(intent?.extras!!.getString("FinalImageUri"))
//        val FinalText = intent?.extras!!.getString("FinalText")
//        val community = intent?.extras!!.getString("community")
//        bundle.putString("finalImage", FinalImageUri.toString())
//        bundle.putString("finalText", FinalText)
//        bundle.putString("community", community)
////        val communityFragment = CommunityFragment()
//        val communityFragment = CommunityListFragment()
//        communityFragment.arguments = bundle
//        loadFragment(communityFragment, "community")
//
//        binding.appBar.logo.visibility = View.GONE
//
//        binding.navigateHome.visibility = View.GONE
//        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._0ssp)
//        binding.bottomAppBar.fabCradleRoundedCornerRadius = resources.getDimension(R.dimen._0ssp)
//        val menu: Menu = binding.bottomNavigationView.menu
//        menu.findItem(R.id.home).setIcon(R.drawable.home)
//        menu.findItem(R.id.home).title = "Home"
////        binding.bottomNavigationView.setSelectedItemId(R.id.community)
//
//    }





    private fun initData() {
        loadFragment(HomeFragment(),"home")
        selectBottomViewItems()
        binding.navigateHome.setOnClickListener(View.OnClickListener {
            binding.bottomNavigationView.selectedItemId = R.id.ticket
            binding.appBar.logo.visibility = View.VISIBLE
            loadFragment(TicketFragment(), "tickets")

            binding.navigateHome.visibility = View.VISIBLE
//            val menu: Menu = binding.bottomNavigationView.menu
//            binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._10ssp)
//            binding.bottomAppBar.fabCradleRoundedCornerRadius =fabCradleRoundedCornerRadius
                resources.getDimension(R.dimen._20ssp)
//            menu.findItem(R.id.home).icon = null
//            menu.findItem(R.id.home).title = ""
        })


    }



    private fun selectBottomViewItems() {
        binding.bottomNavigationView.selectedItemId = R.id.home
        binding.bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.home -> {
                  //  setHomeFragment()
                    loadFragment(HomeFragment(),"home")
                    currentFragment = "home"
                    true
                }

                R.id.match -> {
                   // setMatcheFragment()
                    loadFragment(MatchFragment(),"match")
                    currentFragment = "match"

                    true
                }

                R.id.ticket -> {
                    //setTicketsFragment()
                    loadFragment(TicketFragment(),"ticket")
                    currentFragment = "tickets"

                    true
                }

                R.id.players -> {
                   // setPlayersFragment()
                    loadFragment(PlayerFragment(),"player")
                    currentFragment = "players"

                    true
                }

                R.id.more -> {
                  //  setMoreFragment()
                    loadFragment(MoreFragment(),"home")
                    currentFragment = "More"

                    true
                }

                else -> {
                    false
                }
            }
        }

    }

//    private fun setMoreFragment() {
//        loadFragment(MoreFragment(), "More")
//        binding.appBar.logo.visibility = View.VISIBLE
//
//        binding.navigateHome.visibility = View.VISIBLE
//        val menu: Menu = binding.bottomNavigationView.menu
//        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._10ssp)
//        binding.bottomAppBar.fabCradleRoundedCornerRadius = resources.getDimension(R.dimen._20ssp)
//        menu.findItem(R.id.home).icon = null
//        menu.findItem(R.id.home).title = ""
//    }
//
//    private fun setMatcheFragment() {
//        loadFragment(MatchFragment(), "matches")
//        binding.appBar.logo.visibility = View.VISIBLE
//
//        binding.navigateHome.visibility = View.VISIBLE
//        val menu: Menu = binding.bottomNavigationView.menu
//        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._10ssp)
//        binding.bottomAppBar.fabCradleRoundedCornerRadius = resources.getDimension(R.dimen._20ssp)
//        menu.findItem(R.id.home).icon = null
//        menu.findItem(R.id.home).title = ""
//    }
//
//    private fun setPlayersFragment() {
//
//        loadFragment(PlayerFragment(), "players")
//        binding.appBar.logo.visibility = View.VISIBLE
//
//        binding.navigateHome.visibility = View.VISIBLE
//        val menu: Menu = binding.bottomNavigationView.menu
//        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._10ssp)
//        binding.bottomAppBar.fabCradleRoundedCornerRadius = resources.getDimension(R.dimen._20ssp)
//        menu.findItem(R.id.home).icon = null
//        menu.findItem(R.id.home).title = ""
//    }
//
//    private fun setHomeFragment() {
//        binding.appBar.logo.visibility = View.VISIBLE
////        binding.appBar.screenName.visibility = View.GONE
//        loadFragment(HomeFragment(), "home")
//
//        binding.navigateHome.visibility = View.VISIBLE
//        val menu: Menu =
//            binding.bottomNavigationView.menu
//        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._10ssp)
//        binding.bottomAppBar.fabCradleRoundedCornerRadius = resources.getDimension(R.dimen._20ssp)
//        binding.bottomAppBar.background = resources.getDrawable(R.drawable.bg_gradient)
//
//
//        menu.findItem(R.id.home).icon = null
//        menu.findItem(R.id.home).title = ""
//
//    }
//
//    private fun setTicketsFragment() {
////        loadFragment(CommunityFragment())
//        loadFragment(TicketFragment(), "tickets")
//        binding.appBar.logo.visibility = View.VISIBLE
//
//        binding.navigateHome.visibility = View.GONE
//        binding.bottomAppBar.fabCradleMargin = resources.getDimension(R.dimen._0ssp)
//        binding.bottomAppBar.fabCradleRoundedCornerRadius = resources.getDimension(R.dimen._0ssp)
//        val menu: Menu = binding.bottomNavigationView.menu
//        menu.findItem(R.id.home).setIcon(R.drawable.logo)
//        binding.bottomAppBar.background = resources.getDrawable(R.drawable.bg_gradient)
//
//        menu.findItem(R.id.home).title = "tickets"
//    }

    private fun loadFragment(fragment: Fragment, tag: String) {
        val fragmentManager: FragmentManager = supportFragmentManager
        val fragmentTransaction: FragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.container, fragment, tag).addToBackStack(null).commit()

    }

}
